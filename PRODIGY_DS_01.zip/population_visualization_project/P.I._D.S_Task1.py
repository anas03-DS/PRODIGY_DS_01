import pandas as pd
import matplotlib.pyplot as plt

# Load your dataset
data = pd.read_csv('D://1 Intern\Population of India.csv')

# Set the state names as the index (if required)
data.set_index('State/UT', inplace=True)
# Create a bar chart for male and female populations
data[['Male', 'Female']].plot(kind='bar', figsize=(12, 8), color=['blue', 'pink'], width= 0.35)
plt.title('Male vs. Female Population by State in India')
plt.xlabel('States')
plt.ylabel('Population')
plt.xticks(rotation=90)
plt.subplots_adjust(bottom=0.2)
plt.tight_layout() 
plt.legend(title='Gender')
plt.show()

