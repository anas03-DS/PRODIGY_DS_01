# Population Visualization Project

## Project Description
This project visualizes the male and female population counts by state in India using a bar chart. The dataset includes the male and female population for each state/UT in India.

## Requirements
To run this project, you need to install the following Python libraries:
- `pandas`
- `matplotlib`

You can install them using:
pip install pandas matplotlib seaborn
pip install fsspec
